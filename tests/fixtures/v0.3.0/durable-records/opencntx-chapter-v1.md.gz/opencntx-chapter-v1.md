+++
format = "opencntx-chapter"
format_version = 1
chapter_id = "CH-FIXTURE"
title = "Fixture"
scope = "v0.3 contract fixture"
revision = 1
knowledge_status = "DRAFT"
last_owner_approval = ""
dependency_ids = []
source_refs = []
+++

# Fixture
