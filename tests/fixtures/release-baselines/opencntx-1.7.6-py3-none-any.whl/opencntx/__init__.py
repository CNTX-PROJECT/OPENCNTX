"""OPENCNTX public package."""

__version__ = "1.7.6"
